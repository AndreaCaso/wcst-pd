%% Initialise all the three cognitive schemas

o_EXT_PFC(1,1:timeSteps) = extPFC + unifrnd(-extNoise,extNoise);
  
o_EXT_PFC(2,1:timeSteps) = extPFC + unifrnd(-extNoise,extNoise);

o_EXT_PFC(3,1:timeSteps) = extPFC + unifrnd(-extNoise,extNoise);
