%% Shows a new card

if (counter.trial_num_time == 0)
    
    %fprintf('Displaying %1i %s %s \n', stimuli(counter.trial_num).itemnum, char(stimuli(counter.trial_num).colour), char(stimuli(counter.trial_num).shape));
    %fprintf(fileID, '[TIME = %4.0f] Displaying %1i %s %s \n', tt, stimuli(counter.trial_num).itemnum, char(stimuli(counter.trial_num).colour), char(stimuli(counter.trial_num).shape));

end
%% 
